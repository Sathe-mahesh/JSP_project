package fmi.code;



import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Load the MySQL JDBC driver
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new IllegalStateException("MySQL JDBC Driver not found", e);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        String action = request.getParameter("action");

        if ("login".equals(action)) {
            // Login action
            try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/userdb", "root", "root")) {
                String username = request.getParameter("txtName");
                String password = request.getParameter("txtPwd");

                // Prepare the SQL statement to check login credentials
                String sql = "SELECT uname FROM login WHERE uname=? AND password=?";
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setString(1, username);
                    ps.setString(2, password);

                    // Execute the query
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            // Login successful
                            response.sendRedirect("welcome.jsp");
                        } else {
                            // Login failed
                            out.println("<font color=\"red\">Login failed. Invalid username or password.</font><br>");
                            out.println("<a href=\"login.jsp\">Try again</a>");
                        }
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
                out.println("An error occurred. Please try again later.");
            }
        } else if ("forgotPassword".equals(action)) {
            // Forgot password action
            String email = request.getParameter("email");
            // Logic to reset password and send it to the email
            // This part is implementation-specific and depends on your system design
            out.println("Password reset link sent to your email: " + email);
        } else {
            // Invalid action
            out.println("Invalid action.");
        }
    }

    @Override
    public void destroy() {
        try {
            // Unregister JDBC driver
            DriverManager.deregisterDriver(DriverManager.getDriver("jdbc:mysql://localhost:3306/userdb"));
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Stop MySQL abandoned connection cleanup thread
        com.mysql.cj.jdbc.AbandonedConnectionCleanupThread.checkedShutdown();
    }
}
