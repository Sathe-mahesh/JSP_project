package fmi.codes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
public class RegisterDao {
	
public int registeremp(Member member) throws ClassNotFoundException
{
	//#   uname, password, email, phone

	 String sql = "insert into member (uname, password, email, phone) values (?,?,?,?)";
	 int result=0;
	 Class.forName("com.mysql.jdbc.Driver");
	 String url="jdbc:mysql://localhost:3306/userdb?user=root&password=root";
	
	 try(Connection con = DriverManager.getConnection(url);
			 PreparedStatement ps = con.prepareStatement(sql); 
			 ) {

		 ps.setString(1, member.getUname());
		 ps.setString(2, member.getPassword());
		 ps.setString(3, member.getEmail());
		 ps.setNString(4, member.getPhone());
		  
		 result=ps.executeUpdate();
		 } catch (SQLException e) {
		   e.printStackTrace();
		 }
 return result;
 }
}