package fmi.codes;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
 
 
@WebServlet("/Register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private RegisterDao registerDao;
   public void init()
   {
	  registerDao = new RegisterDao(); 
   }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int regEmp=0;
		
	     String Uname=request.getParameter("uname");
		 String Password=request.getParameter("password");
		 String Email=request.getParameter("email");
		 String Phone=request.getParameter("phone");
		 
		 Member member = new Member();
		 member.setUname(Uname);
		 member.setPassword(Password);
		 member.setEmail(Email);
		 member.setPhone(Phone);
		 
		 try
		 {
			 regEmp =  registerDao.registeremp(member);
			 if(regEmp>0)
			 {
				 request.setAttribute("Uname", member.getUname());
				 request.setAttribute("Password", member.getPassword());
				 request.setAttribute("Email", member.getEmail());
				 request.setAttribute("Phone", member.getPhone());
				 
RequestDispatcher rd = request.getRequestDispatcher("empregisterDone.jsp");
rd.forward(request, response);
			 }
			 else
			 {
				 RequestDispatcher rd = request.getRequestDispatcher("empregisterfailed.jsp");
				 rd.forward(request, response);
			 }
			 
		 }
		 catch(Exception e)
		 {
			 
		 }
		 
		 
	}

}
